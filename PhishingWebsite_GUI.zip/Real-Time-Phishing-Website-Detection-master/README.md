# Real-Time-Phishing-Website-Detection
Using Machine learning classifier developed GUI which takes the url of suspicious websites as input and tells the user if it is a benign or malicious website and thus prevents the users from accessing malicious websites.
The accuracy obtained was of the order 0.961.
